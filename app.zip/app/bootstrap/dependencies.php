<?php
/**
 * By RmnJL
 * Github: https://github.com/RmnJL
 */


if (!defined('PATH')) die();

$depPath = PATH_BOOTSTRAP . DS . "dependencies";

foreach (glob("$depPath/*.php") as $filename) {
    require_once($filename);
}
