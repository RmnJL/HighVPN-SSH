<?php

/**
 * By RmnJL
 * Github: https://github.com/RmnJL
 */

namespace App\Controllers;


class Cronjob extends BaseController
{

    public function master($request, $response, $arg)
    {
        $cModel = new \App\Models\Cronjob();
        $cModel->init();

    }
}
