<?php

/**
 * By RmnJL
 * Github: https://github.com/RmnJL
 */

define('PATH', __DIR__);


require_once 'vendor/autoload.php';
require_once 'bootstrap/bootstrap.php';
