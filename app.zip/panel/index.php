<?php

/**
 * Powered by RaminJL
 * Github: https://github.com/RmnJL
 */

define('PATH', __DIR__);


require_once 'vendor/autoload.php';
require_once 'bootstrap/bootstrap.php';
