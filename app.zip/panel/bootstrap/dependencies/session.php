<?php
/**
 * By RmnJL
 * Github: https://github.com/RmnJL
 */

if (!defined('PATH')) die();

if (getConfig('session', 'enabled')) {
  $container['session'] = function ($c) {
    return new \SlimSession\Helper;
  };
}
