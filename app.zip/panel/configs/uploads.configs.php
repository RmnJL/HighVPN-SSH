<?php
/**
 * By RmnJL
 * Github: https://github.com/RmnJL
 */

if (!defined('PATH')) die();

/**
 * Uploads Config
 */
$configs['upload']['dir'] = PATH_ASSETS . DS . 'uploads';
$configs['upload']['temp'] = PATH_TEMP;
$configs['upload']['url'] = $configs['url'] . 'assets/uploads/';

?>
