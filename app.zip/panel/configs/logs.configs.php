<?php 
/**
 * Powered by RaminJL
 * Github: https://github.com/RmnJL
 */

if (!defined('PATH')) die();


$configs['logger']['enabled'] = true;
$configs['logger']['name'] = '';
$configs['logger']['addr'] = '';
?>
